# Preview
![](docs/screenshot.png)

# Code
- src, is the source code of the website
- docs, have images, and text about this website
